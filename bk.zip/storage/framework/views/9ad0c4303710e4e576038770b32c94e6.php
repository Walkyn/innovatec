
<?php $__env->startSection('title', 'Business Manager - Calendario'); ?>

<?php $__env->startSection('content'); ?>

    <!-- ===== Main Content Start ===== -->
    <main>
        <div class="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
            <div class="mx-auto max-w-full">
                <!-- Breadcrumb Start -->
                <div class="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <h2 class="text-title-md2 font-bold text-black dark:text-white">
                        Calendario
                    </h2>

                    <nav>
                        <ol class="flex items-center gap-2">
                            <li>
                                <a class="font-medium" href="index.html">Dashboard /</a>
                            </li>
                            <li class="text-primary">Calendario</li>
                        </ol>
                    </nav>
                </div>
                <!-- Breadcrumb End -->

                <!-- ===== Main Content Start ===== -->
                <main>
                    <div class="mx-auto max-w-(--breakpoint-2xl) p-4 md:p-6">
                        <!-- Breadcrumb Start -->
                        <div x-data="{ pageName: 'Calendar' }">
                            <?php echo $__env->make('partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <!-- Breadcrumb End -->

                        <div class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]">
                            <div id="calendar" class="min-h-screen"></div>
                        </div>

                        <!-- BEGIN MODAL -->
                        <?php echo $__env->make('partials.calendar-event-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- END MODAL -->

                    </div>
                </main>
                <!-- ===== Main Content End ===== -->

            </div>
        </div>
    </main>
    <!-- ===== Main Content End ===== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\innovatec\resources\views/calendar/index.blade.php ENDPATH**/ ?>
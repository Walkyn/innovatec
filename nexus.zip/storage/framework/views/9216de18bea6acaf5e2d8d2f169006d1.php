<div
  class="col-span-12 rounded-sm border border-stroke bg-white px-7.5 py-6 shadow-default dark:border-strokedark dark:bg-boxdark xl:col-span-6"
>
  <h4 class="mb-2 text-xl font-bold text-black dark:text-white">
    Region labels
  </h4>
  <div id="mapOne" class="mapOne map-btn h-90"></div>
</div>
<?php /**PATH C:\laragon\www\innovatec\resources\views/partials/map-01.blade.php ENDPATH**/ ?>